import 'package:flutter/material.dart';
import 'dashboard.dart';  // Importe a tela do Dashboard
import 'poupai.dart';    // Importe a tela do Poupai
import 'metas.dart';     // Importe a tela das Metas

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _paginaAtual = 1; // Para controlar qual página está sendo exibida

  // Lista de páginas que vão ser exibidas com base no índice
  final List<Widget> _telas = [
    DashboardPage(),  // A tela de Dashboard
    PoupaiPage(),     // A tela de Poupai
    MetasPage(),      // A tela de Metas
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Poup.AI'),
      ),
      body: IndexedStack(
        index: _paginaAtual,  // Exibe a página com o índice atual
        children: _telas,      // As telas que serão alternadas
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _paginaAtual,
        onTap: (index) {
          setState(() {
            _paginaAtual = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.pie_chart),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_bubble_outline),
            label: 'Poup.ai',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.flag),
            label: 'Metas',
          ),
        ],
      ),
    );
  }
}
