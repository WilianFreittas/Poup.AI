import 'package:flutter/material.dart';

class MetasPage extends StatefulWidget {
  @override
  _MetasPageState createState() => _MetasPageState();
}

class _MetasPageState extends State<MetasPage> {
  List<Map<String, dynamic>> metas = [];

  List<bool> expandido = [];

  final TextEditingController _tituloController = TextEditingController();
  final TextEditingController _valorMetaController = TextEditingController();
  final TextEditingController _depositadoController = TextEditingController();

  void _abrirFormularioNovaMeta({int? index}) {
    if (index != null) {
      final meta = metas[index];
      _tituloController.text = meta['titulo'];
      _valorMetaController.text = meta['meta'].toString();
      _depositadoController.text = meta['depositado'].toString();
    } else {
      _tituloController.clear();
      _valorMetaController.clear();
      _depositadoController.clear();
    }

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(index == null ? 'Nova Meta' : 'Editar Meta'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: _tituloController,
                decoration: const InputDecoration(labelText: 'Título da Meta'),
              ),
              TextField(
                controller: _valorMetaController,
                decoration: const InputDecoration(labelText: 'Valor da Meta (R\$)'),
                keyboardType: TextInputType.number,
              ),
              TextField(
                controller: _depositadoController,
                decoration: const InputDecoration(labelText: 'Valor já depositado (R\$)'),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            child: const Text('Cancelar'),
            onPressed: () => Navigator.pop(context),
          ),
          ElevatedButton(
            child: const Text('Salvar'),
            onPressed: () {
              final titulo = _tituloController.text.trim();
              final valorMeta = double.tryParse(_valorMetaController.text) ?? 0;
              final valorDepositado = double.tryParse(_depositadoController.text) ?? 0;

              if (titulo.isNotEmpty && valorMeta > 0) {
                setState(() {
                  if (index != null) {
                    metas[index] = {
                      'titulo': titulo,
                      'meta': valorMeta,
                      'depositado': valorDepositado,
                    };
                  } else {
                    metas.add({
                      'titulo': titulo,
                      'meta': valorMeta,
                      'depositado': valorDepositado,
                    });
                    expandido.add(false);
                  }
                });
                Navigator.pop(context);
              }
            },
          ),
        ],
      ),
    );
  }

  void _removerMeta(int index) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Confirmar Exclusão'),
        content: const Text('Deseja realmente excluir esta meta?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                metas.removeAt(index);
                expandido.removeAt(index);
              });
              Navigator.pop(context);
            },
            child: const Text('Excluir'),
          ),
        ],
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2F4F8),
      appBar: AppBar(
        title: const Text('Minhas Metas'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _abrirFormularioNovaMeta(),
        child: const Icon(Icons.add),
        backgroundColor: Color(0xFF006155),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: metas.isEmpty
            ? const Center(child: Text('Nenhuma meta adicionada ainda.'))
            : ListView.builder(
          itemCount: metas.length,
          itemBuilder: (context, index) {
            final meta = metas[index];
            final progresso = (meta['depositado'] / meta['meta']).clamp(0.0, 1.0);
            return GestureDetector(
              onTap: () {
                setState(() {
                  expandido[index] = !expandido[index];
                });
              },
              child: Card(
                elevation: 3,
                margin: const EdgeInsets.symmetric(vertical: 10),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        meta['titulo'],
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 10),
                      LinearProgressIndicator(
                        value: progresso,
                        minHeight: 10,
                        backgroundColor: Colors.grey[300],
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
                      ),
                      const SizedBox(height: 6),
                      Text('${(progresso * 100).toStringAsFixed(0)}% concluído'),
                      if (expandido[index]) ...[
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Valor da Meta:'),
                            Text('R\$ ${meta['meta'].toStringAsFixed(2)}'),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Já depositado:'),
                            Text('R\$ ${meta['depositado'].toStringAsFixed(2)}'),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            TextButton(
                              onPressed: () => _abrirFormularioNovaMeta(index: index),
                              child: const Text('Editar'),
                            ),
                            TextButton(
                              onPressed: () => _removerMeta(index),
                              child: const Text('Excluir', style: TextStyle(color: Colors.red)),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
