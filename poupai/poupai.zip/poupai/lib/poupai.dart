import 'package:flutter/material.dart';

class PoupaiPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Assistente Poup.ai',
        style: TextStyle(fontSize: 24),
      ),
    );
  }
}
