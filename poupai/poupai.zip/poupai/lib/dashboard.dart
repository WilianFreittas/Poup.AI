import 'package:flutter/material.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:fl_chart/fl_chart.dart';
import 'dashboard_widgets.dart';

class DashboardPage extends StatefulWidget {
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final List<String> meses = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril',
    'Maio', 'Junho', 'Julho', 'Agosto',
    'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  final List<int> anos = [2023, 2024, 2025];
  String mesSelecionado = 'Abril';
  int anoSelecionado = 2024;

  Map<String, List<Map<String, dynamic>>> dadosPorPeriodo = {
    'Abril-2024': [
      {
        'categoria': 'Alimentação',
        'valor': 800.0,
        'cor': Colors.orange,
        'icone': Icons.restaurant,
      },
    ]
  };

  Map<String, double> entradasPorPeriodo = {
    'Abril-2024': 3000.0
  };

  final Map<String, IconData> iconesDisponiveis = {
    'Restaurante': Icons.restaurant,
    'Carro': Icons.directions_car,
    'Casa': Icons.home,
    'Lazer': Icons.sports_esports,
    'Mercado': Icons.shopping_cart,
    'Outros': Icons.category,
  };

  String get periodoAtual => '$mesSelecionado-$anoSelecionado';

  double get entradasFixas => entradasPorPeriodo[periodoAtual] ?? 0.0;

  double get totalGastos {
    final lista = dadosPorPeriodo[periodoAtual];
    if (lista == null) return 0.0;
    return lista.fold(0.0, (total, item) => total + item['valor']);
  }

  double get saldo => entradasFixas - totalGastos;

  void _abrirDialogEditarEntradas() {
    final controller = TextEditingController(text: entradasFixas.toStringAsFixed(2));
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Editar Entradas'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(labelText: 'Valor de entrada (R\$)'),
          keyboardType: TextInputType.number,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          ElevatedButton(
            onPressed: () {
              final novoValor = double.tryParse(controller.text);
              if (novoValor != null) {
                setState(() {
                  entradasPorPeriodo[periodoAtual] = novoValor;
                });
              }
              Navigator.pop(context);
            },
            child: const Text('Salvar'),
          ),
        ],
      ),
    );
  }

  void _confirmarExcluirCategoria(int index) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Confirmar Exclusão'),
        content: const Text('Deseja realmente excluir esta categoria?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          ElevatedButton(
            onPressed: () {
              setState(() {
                dadosPorPeriodo[periodoAtual]?.removeAt(index);
              });
              Navigator.pop(context);
            },
            child: const Text('Excluir'),
          ),
        ],
      ),
    );
  }

  void _abrirDialogCategoria({int? index}) {
    final isEditando = index != null;
    final categoria = isEditando ? dadosPorPeriodo[periodoAtual]![index!] : null;

    final nomeController = TextEditingController(text: categoria?['categoria'] ?? '');
    final valorController = TextEditingController(text: categoria?['valor']?.toString() ?? '');
    Color corSelecionada = categoria?['cor'] ?? Colors.green;
    String iconeSelecionadoNome = iconesDisponiveis.entries.firstWhere(
          (e) => e.value == (categoria?['icone'] ?? Icons.category),
      orElse: () => const MapEntry('Outros', Icons.category),
    ).key;

    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setStateDialog) => AlertDialog(
          title: Text(isEditando ? 'Editar Categoria' : 'Nova Categoria'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: nomeController,
                  decoration: const InputDecoration(labelText: 'Nome da categoria'),
                ),
                TextField(
                  controller: valorController,
                  decoration: const InputDecoration(labelText: 'Valor'),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    const Text('Cor: '),
                    const SizedBox(width: 10),
                    GestureDetector(
                      onTap: () async {
                        final cor = await showDialog<Color>(
                          context: context,
                          builder: (_) => AlertDialog(
                            title: const Text('Escolha a cor'),
                            content: SingleChildScrollView(
                              child: BlockPicker(
                                pickerColor: corSelecionada,
                                onColorChanged: (cor) {
                                  setStateDialog(() => corSelecionada = cor);
                                  Navigator.pop(context);
                                },
                              ),
                            ),
                          ),
                        );
                      },
                      child: CircleAvatar(backgroundColor: corSelecionada),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    const Text('Ícone: '),
                    const SizedBox(width: 10),
                    DropdownButton<String>(
                      value: iconeSelecionadoNome,
                      onChanged: (novoNome) => setStateDialog(() => iconeSelecionadoNome = novoNome!),
                      items: iconesDisponiveis.keys.map((nome) {
                        return DropdownMenuItem<String>(
                          value: nome,
                          child: Icon(iconesDisponiveis[nome]),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
            ElevatedButton(
              onPressed: () {
                final nome = nomeController.text.trim();
                final valor = double.tryParse(valorController.text) ?? 0;
                if (nome.isEmpty || valor <= 0) return;

                setState(() {
                  dadosPorPeriodo.putIfAbsent(periodoAtual, () => []);
                  final novaCategoria = {
                    'categoria': nome,
                    'valor': valor,
                    'cor': corSelecionada,
                    'icone': iconesDisponiveis[iconeSelecionadoNome],
                  };
                  if (isEditando) {
                    dadosPorPeriodo[periodoAtual]![index!] = novaCategoria;
                  } else {
                    dadosPorPeriodo[periodoAtual]!.add(novaCategoria);
                  }
                });
                Navigator.pop(context);
              },
              child: const Text('Salvar'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final categorias = dadosPorPeriodo[periodoAtual];

    return Scaffold(
      backgroundColor: const Color(0xFFF2F4F8),
      appBar: AppBar(title: const Text('Dashboard')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            Row(
              children: [
                Expanded(
                  child: DropdownButton<String>(
                    value: mesSelecionado,
                    isExpanded: true,
                    onChanged: (novo) => setState(() => mesSelecionado = novo!),
                    items: meses.map((mes) => DropdownMenuItem(value: mes, child: Text(mes))).toList(),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButton<int>(
                    value: anoSelecionado,
                    isExpanded: true,
                    onChanged: (novo) => setState(() => anoSelecionado = novo!),
                    items: anos.map((ano) => DropdownMenuItem(value: ano, child: Text(ano.toString()))).toList(),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Resumo por Categoria', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                IconButton(
                  onPressed: () => _abrirDialogCategoria(),
                  icon: const Icon(Icons.add_circle, color: Color(0xFF006155), size: 28),
                ),
              ],
            ),
            const SizedBox(height: 20),
            categorias == null || categorias.isEmpty
                ? const Center(
              child: Padding(
                padding: EdgeInsets.all(32.0),
                child: Text(
                  'Nenhuma categoria cadastrada para este período.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
                : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                PieChartWidget(
                  categorias: categorias,
                  totalGastos: totalGastos,
                ),
                const SizedBox(height: 30),
                CategoriaListWidget(
                  categorias: categorias,
                  onEditar: (index) => _abrirDialogCategoria(index: index),
                  onExcluir: (index) => _confirmarExcluirCategoria(index),
                ),
                const Divider(),
                ListTile(
                  title: const Text('Entradas'),
                  trailing: GestureDetector(
                    onTap: _abrirDialogEditarEntradas,
                    child: Text(
                      'R\$ ${entradasFixas.toStringAsFixed(2)}',
                      style: const TextStyle(color: Colors.green, decoration: TextDecoration.underline),
                    ),
                  ),
                ),
                ListTile(
                  title: const Text('Gastos'),
                  trailing: Text('R\$ ${totalGastos.toStringAsFixed(2)}', style: const TextStyle(color: Colors.redAccent)),
                ),
                ListTile(
                  title: const Text('Saldo'),
                  trailing: Text(
                    'R\$ ${saldo.toStringAsFixed(2)}',
                    style: TextStyle(
                      color: saldo >= 0 ? Colors.green : Colors.red,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
