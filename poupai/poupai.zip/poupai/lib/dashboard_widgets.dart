import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class PieChartWidget extends StatelessWidget {
  final List<Map<String, dynamic>> categorias;
  final double totalGastos;

  const PieChartWidget({
    super.key,
    required this.categorias,
    required this.totalGastos,
  });

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1.3,
      child: PieChart(
        PieChartData(
          centerSpaceRadius: 40,
          sectionsSpace: 3,
          sections: categorias.map((item) {
            final valor = item['valor'] ?? 0.0;
            return PieChartSectionData(
              color: item['cor'],
              value: valor,
              title: '${((valor / totalGastos) * 100).toStringAsFixed(1)}%',
              titleStyle: const TextStyle(color: Colors.white),
              radius: 60,
            );
          }).toList(),
        ),
      ),
    );
  }
}

class CategoriaListWidget extends StatelessWidget {
  final List<Map<String, dynamic>> categorias;
  final void Function(int index) onEditar;
  final void Function(int index) onExcluir;

  const CategoriaListWidget({
    super.key,
    required this.categorias,
    required this.onEditar,
    required this.onExcluir,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: categorias.map((item) {
        final index = categorias.indexOf(item);
        return ListTile(
          leading: Icon(item['icone'], color: item['cor']),
          title: Text(item['categoria']),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('R\$ ${item['valor'].toStringAsFixed(2)}'),
              IconButton(
                onPressed: () => onExcluir(index),
                icon: const Icon(Icons.delete, color: Colors.redAccent),
              ),
            ],
          ),
          onTap: () => onEditar(index),
        );
      }).toList(),
    );
  }
}
